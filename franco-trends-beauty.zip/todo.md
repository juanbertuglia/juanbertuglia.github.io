# FRANCO Trends & Beauty — Project TODO

## Base & Infraestructura
- [x] Esquema de base de datos: tablas appointments, services, reviews
- [x] Migraciones SQL aplicadas
- [x] Queries helpers en server/db.ts
- [x] Routers tRPC: appointments, services, reviews, admin

## Diseño & Branding
- [x] Paleta de colores premium (dorado, negro, blanco crema) en index.css
- [x] Tipografías refinadas (Playfair Display + Cormorant Garamond) en index.html
- [x] Animaciones y micro-interacciones elegantes
- [x] Imagen hero generada y subida a CDN

## Secciones del Sitio
- [x] Navbar fija con logo y navegación suave
- [x] Hero section con branding destacado y CTA
- [x] Sección de Servicios con nombre, descripción y precio
- [x] Sección de Opiniones/Reseñas de clientes
- [x] Sección de Redes Sociales con enlaces directos
- [x] Sección de Ubicación con mapa integrado y dirección
- [x] Footer con información de contacto

## Sistema de Turnos
- [x] Formulario de agendamiento: servicio, fecha, horario, datos personales
- [x] Validación completa del formulario
- [x] Lógica de horarios disponibles (9:00–20:00, cada 30 min)
- [x] Confirmación de turno por pantalla
- [x] Notificación al dueño al recibir un turno

## Panel de Administración
- [x] Ruta /admin protegida (solo dueño)
- [x] Vista de todos los turnos (próximos, pasados, cancelados)
- [x] Filtros por estado
- [x] Acciones: confirmar, completar, cancelar turno
- [x] Vista de estadísticas básicas

## Integración Google Calendar
- [x] Eliminada - Sistema de turnos funciona sin Google Calendar

## Testing & Deploy
- [x] Sitio web completamente funcional
- [x] Checkpoint final
