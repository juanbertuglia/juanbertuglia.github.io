import { useState } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Calendar, Clock, User, Phone, Mail, CheckCircle, XCircle,
  Loader2, Lock, Scissors, BarChart3, ArrowLeft, RefreshCw
} from "lucide-react";
import { cn } from "@/lib/utils";
import { getLoginUrl } from "@/const";

type AppointmentStatus = "pending" | "confirmed" | "cancelled" | "completed";

const statusConfig: Record<AppointmentStatus, { label: string; color: string; bg: string }> = {
  pending:   { label: "Pendiente",   color: "text-yellow-700", bg: "bg-yellow-50 border-yellow-200" },
  confirmed: { label: "Confirmado",  color: "text-green-700",  bg: "bg-green-50 border-green-200" },
  cancelled: { label: "Cancelado",   color: "text-red-700",    bg: "bg-red-50 border-red-200" },
  completed: { label: "Completado",  color: "text-blue-700",   bg: "bg-blue-50 border-blue-200" },
};

function StatusBadge({ status }: { status: AppointmentStatus }) {
  const cfg = statusConfig[status];
  return (
    <span className={cn("inline-flex items-center px-2.5 py-0.5 text-xs font-cormorant border", cfg.bg, cfg.color)}>
      {cfg.label}
    </span>
  );
}

function StatCard({ label, value, icon: Icon, color }: { label: string; value: number; icon: React.ElementType; color: string }) {
  return (
    <div className="bg-white border border-stone-200 p-6">
      <div className="flex items-center justify-between mb-3">
        <span className="font-cormorant text-stone-500 text-xs tracking-[0.15em] uppercase">{label}</span>
        <div className={cn("w-8 h-8 rounded-full flex items-center justify-center", color)}>
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <p className="font-serif-display text-3xl text-stone-900">{value}</p>
    </div>
  );
}

export default function AdminPanel() {
  const { user, loading, isAuthenticated } = useAuth();
  const [filter, setFilter] = useState<AppointmentStatus | "all">("all");
  const utils = trpc.useUtils();

  const { data: appointments, isLoading: loadingAppts, refetch } = trpc.admin.appointments.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });
  const { data: stats, isLoading: loadingStats } = trpc.admin.stats.useQuery(undefined, {
    enabled: isAuthenticated && user?.role === "admin",
  });

  const updateStatus = trpc.admin.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Estado actualizado correctamente.");
      utils.admin.appointments.invalidate();
      utils.admin.stats.invalidate();
    },
    onError: (err) => toast.error("Error: " + err.message),
  });

  // Loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-amber-500" />
      </div>
    );
  }

  // Not authenticated
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-stone-900 flex items-center justify-center px-6">
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center mx-auto mb-6">
            <Lock className="w-7 h-7 text-amber-400" />
          </div>
          <h1 className="font-serif-display text-2xl text-white mb-3">Acceso Restringido</h1>
          <p className="font-cormorant text-stone-400 mb-8">
            Este panel es exclusivo para el administrador de FRANCO Trends & Beauty.
          </p>
          <a href={getLoginUrl()}>
            <Button className="bg-amber-500 hover:bg-amber-600 text-white font-cormorant tracking-wide uppercase rounded-none px-8">
              Iniciar Sesión
            </Button>
          </a>
          <div className="mt-4">
            <Link href="/" className="font-cormorant text-stone-500 hover:text-amber-400 text-sm tracking-wide uppercase transition-colors">
              ← Volver al inicio
            </Link>
          </div>
        </div>
      </div>
    );
  }

  // Not admin
  if (user?.role !== "admin") {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center px-6">
        <div className="text-center max-w-sm">
          <div className="w-16 h-16 rounded-full bg-red-50 border border-red-200 flex items-center justify-center mx-auto mb-6">
            <Lock className="w-7 h-7 text-red-400" />
          </div>
          <h1 className="font-serif-display text-2xl text-stone-900 mb-3">Sin Acceso</h1>
          <p className="font-cormorant text-stone-500 mb-8">
            Tu cuenta no tiene permisos de administrador.
          </p>
          <Link href="/">
            <Button variant="outline" className="font-cormorant tracking-wide uppercase rounded-none">
              Volver al inicio
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const filtered = appointments?.filter(a =>
    filter === "all" ? true : a.status === filter
  ) ?? [];

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr + "T12:00:00");
    return d.toLocaleDateString("es-AR", { weekday: "short", day: "numeric", month: "short" });
  };

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <div className="bg-stone-900 text-white py-8 px-6">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
              <Scissors className="w-4 h-4 text-white" strokeWidth={1.5} />
            </div>
            <div>
              <div className="font-serif-display text-lg text-white leading-none">FRANCO</div>
              <div className="font-cormorant text-xs text-amber-400 tracking-[0.2em] uppercase">Panel de Administración</div>
            </div>
          </div>
          <div className="flex items-center gap-4">
            <span className="font-cormorant text-stone-400 text-sm hidden sm:block">
              Hola, {user.name ?? "Admin"}
            </span>
            <Link href="/">
              <Button variant="outline" size="sm" className="font-cormorant tracking-wide uppercase rounded-none border-stone-700 text-stone-300 hover:text-white hover:border-stone-500 bg-transparent">
                <ArrowLeft className="w-3.5 h-3.5 mr-1.5" /> Sitio
              </Button>
            </Link>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-6 py-10">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-10">
          <StatCard label="Total" value={stats?.total ?? 0} icon={Calendar} color="bg-stone-100 text-stone-600" />
          <StatCard label="Hoy" value={stats?.todayCount ?? 0} icon={Clock} color="bg-amber-50 text-amber-600" />
          <StatCard label="Confirmados" value={stats?.confirmed ?? 0} icon={CheckCircle} color="bg-green-50 text-green-600" />
          <StatCard label="Pendientes" value={stats?.pending ?? 0} icon={BarChart3} color="bg-yellow-50 text-yellow-600" />
          <StatCard label="Cancelados" value={stats?.cancelled ?? 0} icon={XCircle} color="bg-red-50 text-red-600" />
        </div>

        {/* Appointments table */}
        <div className="bg-white border border-stone-200 shadow-sm">
          {/* Table header */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-6 border-b border-stone-100">
            <h2 className="font-serif-display text-xl text-stone-900">Turnos</h2>
            <div className="flex flex-wrap items-center gap-2">
              {(["all", "pending", "confirmed", "cancelled", "completed"] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setFilter(f)}
                  className={cn(
                    "font-cormorant text-xs tracking-wide uppercase px-3 py-1.5 border transition-colors",
                    filter === f
                      ? "bg-stone-900 text-white border-stone-900"
                      : "border-stone-200 text-stone-500 hover:border-stone-400"
                  )}
                >
                  {f === "all" ? "Todos" : statusConfig[f].label}
                </button>
              ))}
              <button
                onClick={() => refetch()}
                className="p-1.5 border border-stone-200 hover:border-amber-400 text-stone-400 hover:text-amber-600 transition-colors"
                title="Actualizar"
              >
                <RefreshCw className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Table */}
          {loadingAppts ? (
            <div className="flex items-center justify-center py-20">
              <Loader2 className="w-6 h-6 animate-spin text-amber-500" />
            </div>
          ) : filtered.length === 0 ? (
            <div className="text-center py-20">
              <Calendar className="w-10 h-10 text-stone-300 mx-auto mb-3" />
              <p className="font-cormorant text-stone-400 text-lg">No hay turnos para mostrar</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-stone-100">
                    {["Cliente", "Servicio", "Fecha", "Hora", "Estado", "Acciones"].map(h => (
                      <th key={h} className="text-left px-6 py-3 font-cormorant text-xs tracking-[0.15em] uppercase text-stone-400">
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {filtered.map(appt => (
                    <tr key={appt.id} className="border-b border-stone-50 hover:bg-stone-50/50 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-full bg-amber-50 border border-amber-100 flex items-center justify-center flex-shrink-0">
                            <User className="w-3.5 h-3.5 text-amber-600" />
                          </div>
                          <div>
                            <p className="font-cormorant text-stone-900 text-sm font-medium">{appt.clientName}</p>
                            <div className="flex items-center gap-3 mt-0.5">
                              <span className="font-cormorant text-stone-400 text-xs flex items-center gap-1">
                                <Mail className="w-2.5 h-2.5" />{appt.clientEmail}
                              </span>
                              <span className="font-cormorant text-stone-400 text-xs flex items-center gap-1">
                                <Phone className="w-2.5 h-2.5" />{appt.clientPhone}
                              </span>
                            </div>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-cormorant text-stone-700 text-sm">{appt.serviceName}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-cormorant text-stone-600 text-sm">{formatDate(appt.appointmentDate)}</span>
                      </td>
                      <td className="px-6 py-4">
                        <span className="font-cormorant text-stone-600 text-sm">{appt.appointmentTime}</span>
                      </td>
                      <td className="px-6 py-4">
                        <StatusBadge status={appt.status as AppointmentStatus} />
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          {appt.status === "pending" && (
                            <button
                              onClick={() => updateStatus.mutate({ id: appt.id, status: "confirmed" })}
                              disabled={updateStatus.isPending}
                              className="font-cormorant text-xs tracking-wide uppercase text-green-600 hover:text-green-700 border border-green-200 hover:border-green-400 px-2.5 py-1 transition-colors"
                            >
                              Confirmar
                            </button>
                          )}
                          {appt.status === "confirmed" && (
                            <button
                              onClick={() => updateStatus.mutate({ id: appt.id, status: "completed" })}
                              disabled={updateStatus.isPending}
                              className="font-cormorant text-xs tracking-wide uppercase text-blue-600 hover:text-blue-700 border border-blue-200 hover:border-blue-400 px-2.5 py-1 transition-colors"
                            >
                              Completar
                            </button>
                          )}
                          {(appt.status === "pending" || appt.status === "confirmed") && (
                            <button
                              onClick={() => {
                                if (confirm("¿Cancelar este turno?")) {
                                  updateStatus.mutate({ id: appt.id, status: "cancelled" });
                                }
                              }}
                              disabled={updateStatus.isPending}
                              className="font-cormorant text-xs tracking-wide uppercase text-red-500 hover:text-red-700 border border-red-100 hover:border-red-300 px-2.5 py-1 transition-colors"
                            >
                              Cancelar
                            </button>
                          )}

                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
