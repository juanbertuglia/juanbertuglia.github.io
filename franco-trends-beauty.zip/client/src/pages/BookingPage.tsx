import { useState, useMemo } from "react";
import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { ArrowLeft, Calendar, Clock, User, Mail, Phone, CheckCircle, Scissors } from "lucide-react";
import { cn } from "@/lib/utils";

type Step = "service" | "datetime" | "personal" | "confirm";

interface BookingData {
  serviceIds: number[];
  serviceNames: string[];
  totalPrice: number;
  date: string;
  time: string;
  clientName: string;
  clientEmail: string;
  clientPhone: string;
  notes: string;
}

const STEPS: { id: Step; label: string }[] = [
  { id: "service", label: "Servicios" },
  { id: "datetime", label: "Fecha y Hora" },
  { id: "personal", label: "Tus Datos" },
  { id: "confirm", label: "Confirmación" },
];

function StepIndicator({ current }: { current: Step }) {
  const idx = STEPS.findIndex(s => s.id === current);
  return (
    <div className="flex items-center justify-center gap-0 mb-12">
      {STEPS.map((step, i) => (
        <div key={step.id} className="flex items-center">
          <div className={cn(
            "w-8 h-8 rounded-full flex items-center justify-center text-xs font-cormorant font-bold transition-all duration-300",
            i < idx ? "bg-amber-500 text-white" :
            i === idx ? "bg-stone-900 text-white ring-2 ring-amber-400 ring-offset-2" :
            "bg-stone-100 text-stone-400"
          )}>
            {i < idx ? "✓" : i + 1}
          </div>
          <span className={cn(
            "ml-2 font-cormorant text-xs tracking-wide uppercase hidden sm:block",
            i === idx ? "text-stone-900" : "text-stone-400"
          )}>
            {step.label}
          </span>
          {i < STEPS.length - 1 && (
            <div className={cn(
              "w-8 sm:w-16 h-px mx-3 transition-colors duration-300",
              i < idx ? "bg-amber-400" : "bg-stone-200"
            )} />
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Step 1: Services (Multiple) ──────────────────────────────────────────────
function ServiceStep({ 
  onSelect,
  onServiceSelect,
}: { 
  onSelect: (ids: number[], names: string[], total: number) => void;
  onServiceSelect: (ids: number[]) => void;
}) {
  const { data: services, isLoading } = trpc.services.list.useQuery();
  const [selected, setSelected] = useState<Set<number>>(new Set());

  const formatPrice = (p: number) =>
    new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(p);

  const totalPrice = useMemo(() => {
    if (!services) return 0;
    return Array.from(selected).reduce((sum, id) => {
      const svc = services.find(s => s.id === id);
      return sum + (svc?.price ?? 0);
    }, 0);
  }, [selected, services]);

  const toggleService = (id: number) => {
    const newSet = new Set(selected);
    if (newSet.has(id)) newSet.delete(id);
    else newSet.add(id);
    setSelected(newSet);
  };

  const selectedServices = services?.filter(s => selected.has(s.id)) ?? [];

  return (
    <div>
      <h2 className="font-serif-display text-2xl text-stone-900 mb-2">Elegí tus servicios</h2>
      <p className="font-cormorant text-stone-500 mb-8">Podés seleccionar uno o más servicios.</p>

      {isLoading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {[...Array(6)].map((_, i) => <div key={i} className="h-28 bg-stone-100 animate-pulse" />)}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
            {services?.map(s => (
              <div
                key={s.id}
                onClick={() => toggleService(s.id)}
                className={cn(
                  "text-left p-5 border transition-all duration-200 cursor-pointer flex items-start gap-3",
                  selected.has(s.id)
                    ? "border-amber-500 bg-amber-50 shadow-sm"
                    : "border-stone-200 hover:border-amber-300 hover:bg-stone-50"
                )}
              >
                <Checkbox
                  checked={selected.has(s.id)}
                  onChange={() => {}}
                  className="mt-1 flex-shrink-0"
                />
                <div className="flex-1">
                  <div className="flex justify-between items-start mb-1">
                    <span className="font-serif-display text-base text-stone-900">{s.name}</span>
                    <span className="font-cormorant text-amber-600 font-semibold text-sm ml-2 flex-shrink-0">
                      {formatPrice(s.price)}
                    </span>
                  </div>
                  <p className="font-cormorant text-stone-500 text-xs leading-relaxed line-clamp-2">{s.description}</p>
                  <span className="font-cormorant text-stone-400 text-xs mt-1 block">{s.durationMinutes} min</span>
                </div>
              </div>
            ))}
          </div>

          {/* Selected services summary */}
          {selectedServices.length > 0 && (
            <div className="bg-amber-50 border border-amber-200 p-4 mb-8">
              <p className="font-cormorant text-amber-900 text-sm mb-2 font-semibold">Servicios seleccionados:</p>
              <div className="space-y-1 mb-3">
                {selectedServices.map(s => (
                  <div key={s.id} className="flex justify-between text-sm font-cormorant text-amber-800">
                    <span>{s.name} ({s.durationMinutes} min)</span>
                    <span>{formatPrice(s.price)}</span>
                  </div>
                ))}
              </div>
              <div className="border-t border-amber-200 pt-2 flex justify-between font-serif-display text-base text-amber-900">
                <span>Total:</span>
                <span className="font-bold">{formatPrice(totalPrice)}</span>
              </div>
            </div>
          )}
        </>
      )}

      <Button
        disabled={selected.size === 0}
        onClick={() => {
          const names = selectedServices.map(s => s.name);
          onServiceSelect(Array.from(selected));
          onSelect(Array.from(selected), names, totalPrice);
        }}
        className="w-full bg-stone-900 hover:bg-amber-600 text-white font-cormorant tracking-[0.1em] uppercase py-5 rounded-none transition-colors"
      >
        Continuar
      </Button>
    </div>
  );
}

// ─── Step 2: Date & Time ──────────────────────────────────────────────────────
function DateTimeStep({
  onSelect,
  onBack,
  selectedServiceIds,
}: {
  onSelect: (date: string, time: string) => void;
  onBack: () => void;
  selectedServiceIds: number[];
}) {
  const today = new Date();
  const [selectedDate, setSelectedDate] = useState<string>("");
  const [selectedTime, setSelectedTime] = useState<string>("");

  const { data: slots, isLoading } = trpc.appointments.getAvailableTimes.useQuery(
    { date: selectedDate },
    { enabled: !!selectedDate }
  );

  // Generate next 30 days (excluding Sundays and Mondays)
  const availableDates = useMemo(() => {
    const dates: string[] = [];
    const d = new Date(today);
    d.setDate(d.getDate() + 1); // Start from tomorrow
    while (dates.length < 30) {
      const dayOfWeek = d.getDay();
      // Skip Sundays (0) and Mondays (1)
      if (dayOfWeek !== 0 && dayOfWeek !== 1) {
        dates.push(d.toISOString().split("T")[0]);
      }
      d.setDate(d.getDate() + 1);
    }
    return dates;
  }, []);

  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr + "T12:00:00");
    return d.toLocaleDateString("es-AR", { weekday: "short", day: "numeric", month: "short" });
  };

  return (
    <div>
      <h2 className="font-serif-display text-2xl text-stone-900 mb-2">Elegí fecha y horario</h2>
      <p className="font-cormorant text-stone-500 mb-8">Martes a sábado, 9:00 a 20:00.</p>

      {/* Date picker */}
      <div className="mb-8">
        <Label className="font-cormorant text-stone-700 tracking-wide uppercase text-xs mb-3 block">
          <Calendar className="w-3.5 h-3.5 inline mr-1.5" />
          Fecha
        </Label>
        <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 max-h-48 overflow-y-auto pr-1">
          {availableDates.map(date => (
            <button
              key={date}
              onClick={() => { setSelectedDate(date); setSelectedTime(""); }}
              className={cn(
                "p-2.5 text-center border transition-all duration-200 text-xs",
                selectedDate === date
                  ? "border-amber-500 bg-amber-50 text-stone-900"
                  : "border-stone-200 hover:border-amber-300 text-stone-600"
              )}
            >
              <span className="font-cormorant block">{formatDate(date)}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Time slots */}
      {selectedDate && (
        <div className="mb-8">
          <Label className="font-cormorant text-stone-700 tracking-wide uppercase text-xs mb-3 block">
            <Clock className="w-3.5 h-3.5 inline mr-1.5" />
            Horario disponible
          </Label>
          {isLoading ? (
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {[...Array(12)].map((_, i) => <div key={i} className="h-10 bg-stone-100 animate-pulse" />)}
            </div>
          ) : (
            <div className="grid grid-cols-4 sm:grid-cols-6 gap-2">
              {slots?.map(slot => (
                <button
                  key={slot.time}
                  disabled={!slot.available}
                  onClick={() => setSelectedTime(slot.time)}
                  className={cn(
                    "py-2.5 text-center border transition-all duration-200 font-cormorant text-sm",
                    !slot.available
                      ? "border-stone-100 bg-stone-50 text-stone-300 cursor-not-allowed line-through"
                      : selectedTime === slot.time
                        ? "border-amber-500 bg-amber-50 text-stone-900"
                        : "border-stone-200 hover:border-amber-300 text-stone-600"
                  )}
                >
                  {slot.time}
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      <div className="flex gap-3">
        <Button
          variant="outline"
          onClick={onBack}
          className="flex-1 font-cormorant tracking-wide uppercase rounded-none border-stone-300"
        >
          <ArrowLeft className="w-4 h-4 mr-1.5" /> Atrás
        </Button>
        <Button
          disabled={!selectedDate || !selectedTime}
          onClick={() => onSelect(selectedDate, selectedTime)}
          className="flex-1 bg-stone-900 hover:bg-amber-600 text-white font-cormorant tracking-[0.1em] uppercase py-5 rounded-none transition-colors"
        >
          Continuar
        </Button>
      </div>
    </div>
  );
}

// ─── Step 3: Personal data ────────────────────────────────────────────────────
function PersonalStep({
  onSubmit,
  onBack,
  isLoading,
}: {
  onSubmit: (name: string, email: string, phone: string, notes: string) => void;
  onBack: () => void;
  isLoading: boolean;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [notes, setNotes] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !phone.trim()) {
      toast.error("Por favor completá todos los campos obligatorios.");
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      toast.error("El email no es válido.");
      return;
    }
    onSubmit(name.trim(), email.trim(), phone.trim(), notes.trim());
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2 className="font-serif-display text-2xl text-stone-900 mb-2">Tus datos personales</h2>
      <p className="font-cormorant text-stone-500 mb-8">Completá tus datos para confirmar la reserva.</p>

      <div className="space-y-5 mb-8">
        <div>
          <Label className="font-cormorant text-stone-700 tracking-wide uppercase text-xs mb-2 block">
            <User className="w-3.5 h-3.5 inline mr-1.5" />
            Nombre completo *
          </Label>
          <Input
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Tu nombre y apellido"
            className="font-cormorant rounded-none border-stone-300 focus:border-amber-500 focus:ring-amber-500/20"
            required
          />
        </div>
        <div>
          <Label className="font-cormorant text-stone-700 tracking-wide uppercase text-xs mb-2 block">
            <Mail className="w-3.5 h-3.5 inline mr-1.5" />
            Email *
          </Label>
          <Input
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            placeholder="tu@email.com"
            className="font-cormorant rounded-none border-stone-300 focus:border-amber-500"
            required
          />
        </div>
        <div>
          <Label className="font-cormorant text-stone-700 tracking-wide uppercase text-xs mb-2 block">
            <Phone className="w-3.5 h-3.5 inline mr-1.5" />
            Teléfono *
          </Label>
          <Input
            type="tel"
            value={phone}
            onChange={e => setPhone(e.target.value)}
            placeholder="+54 9 11 0000-0000"
            className="font-cormorant rounded-none border-stone-300 focus:border-amber-500"
            required
          />
        </div>
        <div>
          <Label className="font-cormorant text-stone-700 tracking-wide uppercase text-xs mb-2 block">
            Notas adicionales (opcional)
          </Label>
          <Textarea
            value={notes}
            onChange={e => setNotes(e.target.value)}
            placeholder="¿Alguna preferencia o consulta especial?"
            className="font-cormorant rounded-none border-stone-300 focus:border-amber-500 resize-none"
            rows={3}
          />
        </div>
      </div>

      <div className="flex gap-3">
        <Button
          type="button"
          variant="outline"
          onClick={onBack}
          className="flex-1 font-cormorant tracking-wide uppercase rounded-none border-stone-300"
        >
          <ArrowLeft className="w-4 h-4 mr-1.5" /> Atrás
        </Button>
        <Button
          type="submit"
          disabled={isLoading}
          className="flex-1 bg-stone-900 hover:bg-amber-600 text-white font-cormorant tracking-[0.1em] uppercase py-5 rounded-none transition-colors"
        >
          {isLoading ? "Reservando..." : "Confirmar Turno"}
        </Button>
      </div>
    </form>
  );
}

// ─── Step 4: Confirmation ─────────────────────────────────────────────────────
function ConfirmationStep({ booking }: { booking: BookingData }) {
  const formatDate = (dateStr: string) => {
    const d = new Date(dateStr + "T12:00:00");
    return d.toLocaleDateString("es-AR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  };

  const formatPrice = (p: number) =>
    new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(p);

  return (
    <div className="text-center">
      <div className="w-16 h-16 rounded-full bg-green-50 border-2 border-green-400 flex items-center justify-center mx-auto mb-6">
        <CheckCircle className="w-8 h-8 text-green-500" />
      </div>

      <h2 className="font-serif-display text-2xl text-stone-900 mb-2">¡Turno confirmado!</h2>
      <p className="font-cormorant text-stone-500 mb-8 text-lg">
        Tu reserva fue registrada exitosamente. Te esperamos en FRANCO Trends & Beauty.
      </p>

      {/* Summary card */}
      <div className="bg-stone-50 border border-stone-200 p-7 text-left mb-6 max-w-sm mx-auto">
        <h3 className="font-serif-display text-base text-stone-900 mb-4">Resumen de tu turno</h3>
        <div className="space-y-3">
          <div>
            <span className="font-cormorant text-stone-400 text-sm uppercase tracking-wide">Servicios</span>
            <div className="mt-1 space-y-1">
              {booking.serviceNames.map((name, i) => (
                <p key={i} className="font-cormorant text-stone-800 text-sm">• {name}</p>
              ))}
            </div>
          </div>
          {[
            { label: "Fecha", value: formatDate(booking.date) },
            { label: "Horario", value: booking.time + " hs" },
            { label: "Cliente", value: booking.clientName },
            { label: "Total", value: formatPrice(booking.totalPrice) },
          ].map(({ label, value }) => (
            <div key={label} className="flex justify-between gap-4">
              <span className="font-cormorant text-stone-400 text-sm uppercase tracking-wide">{label}</span>
              <span className="font-cormorant text-stone-800 text-sm text-right">{value}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-4">
        <Link href="/">
          <Button
            variant="outline"
            className="font-cormorant tracking-wide uppercase rounded-none border-stone-300 hover:border-amber-500"
          >
            Volver al inicio
          </Button>
        </Link>
      </div>
    </div>
  );
}

// ─── Main page ────────────────────────────────────────────────────────────────
export default function BookingPage() {
  const [step, setStep] = useState<Step>("service");
  const [booking, setBooking] = useState<Partial<BookingData>>({});
  const [selectedServiceIds, setSelectedServiceIds] = useState<number[]>([]);

  const createMutation = trpc.appointments.create.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        setStep("confirm");
      }
    },
    onError: (err) => {
      toast.error("Error al reservar: " + err.message);
    },
  });

  return (
    <div className="min-h-screen bg-stone-50">
      {/* Header */}
      <div className="bg-stone-900 text-white py-16">
        <div className="container mx-auto px-6 text-center">
          <div className="flex items-center justify-center gap-2.5 mb-4">
            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
              <Scissors className="w-4 h-4 text-white" strokeWidth={1.5} />
            </div>
          </div>
          <p className="font-cormorant text-amber-400 tracking-[0.35em] uppercase text-sm mb-2">
            FRANCO Trends & Beauty
          </p>
          <h1 className="font-serif-display text-3xl md:text-4xl text-white">
            Reservar Turno
          </h1>
          <p className="font-cormorant text-stone-400 mt-2 text-lg">
            Agendá tu cita en minutos, sin llamadas
          </p>
        </div>
      </div>

      {/* Back link */}
      <div className="container mx-auto px-6 pt-6">
        <Link href="/" className="inline-flex items-center gap-1.5 font-cormorant text-stone-500 hover:text-amber-600 text-sm tracking-wide uppercase transition-colors">
          <ArrowLeft className="w-3.5 h-3.5" /> Volver al inicio
        </Link>
      </div>

      {/* Form */}
      <div className="container mx-auto px-6 py-10">
        <div className="max-w-2xl mx-auto bg-white border border-stone-200 shadow-sm p-8 md:p-12">
          {step !== "confirm" && <StepIndicator current={step} />}

          {step === "service" && (
            <ServiceStep
              onServiceSelect={(ids) => setSelectedServiceIds(ids)}
              onSelect={(ids, names, total) => {
                setBooking(b => ({ ...b, serviceIds: ids, serviceNames: names, totalPrice: total }));
                setStep("datetime");
              }}
            />
          )}

          {step === "datetime" && (
            <DateTimeStep
              selectedServiceIds={selectedServiceIds}
              onSelect={(date, time) => {
                setBooking(b => ({ ...b, date, time }));
                setStep("personal");
              }}
              onBack={() => setStep("service")}
            />
          )}

          {step === "personal" && (
            <PersonalStep
              isLoading={createMutation.isPending}
              onBack={() => setStep("datetime")}
              onSubmit={(name, email, phone, notes) => {
                const full = { ...booking, clientName: name, clientEmail: email, clientPhone: phone, notes } as BookingData;
                setBooking(full);
                
                // Create appointments for each service
                const serviceIds = full.serviceIds ?? [];
                const serviceNames = full.serviceNames ?? [];
                
                if (serviceIds.length === 0) {
                  toast.error("Debes seleccionar al menos un servicio.");
                  return;
                }

                // For simplicity, create one appointment with all services
                createMutation.mutate({
                  clientName: name,
                  clientEmail: email,
                  clientPhone: phone,
                  serviceId: serviceIds[0]!,
                  serviceName: serviceNames.join(" + "),
                  appointmentDate: full.date!,
                  appointmentTime: full.time!,
                  notes: notes || undefined,
                });
              }}
            />
          )}

          {step === "confirm" && booking.date && (
            <ConfirmationStep booking={booking as BookingData} />
          )}
        </div>
      </div>
    </div>
  );
}
