import { useRef } from "react";
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import ServicesSection from "@/components/ServicesSection";
import ReviewsSection from "@/components/ReviewsSection";
import SocialSection from "@/components/SocialSection";
import LocationSection from "@/components/LocationSection";
import Footer from "@/components/Footer";

export default function Home() {
  const servicesRef = useRef<HTMLDivElement>(null);
  const reviewsRef = useRef<HTMLDivElement>(null);
  const socialRef = useRef<HTMLDivElement>(null);
  const locationRef = useRef<HTMLDivElement>(null);

  const scrollTo = (ref: React.RefObject<HTMLDivElement | null>) => {
    ref.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar
        onServicesClick={() => scrollTo(servicesRef)}
        onReviewsClick={() => scrollTo(reviewsRef)}
        onSocialClick={() => scrollTo(socialRef)}
        onLocationClick={() => scrollTo(locationRef)}
      />
      <HeroSection />
      <div ref={servicesRef}>
        <ServicesSection />
      </div>
      <div ref={reviewsRef}>
        <ReviewsSection />
      </div>
      <div ref={socialRef}>
        <SocialSection />
      </div>
      <div ref={locationRef}>
        <LocationSection />
      </div>
      <Footer
        onServicesClick={() => scrollTo(servicesRef)}
        onLocationClick={() => scrollTo(locationRef)}
      />
    </div>
  );
}
