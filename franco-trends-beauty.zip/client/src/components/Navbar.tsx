import { useState, useEffect } from "react";
import { Link } from "wouter";
import { Menu, X, Scissors } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

interface NavbarProps {
  onServicesClick: () => void;
  onReviewsClick: () => void;
  onSocialClick: () => void;
  onLocationClick: () => void;
}

export default function Navbar({ onServicesClick, onReviewsClick, onSocialClick, onLocationClick }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const navLinks = [
    { label: "Servicios", action: onServicesClick },
    { label: "Opiniones", action: onReviewsClick },
    { label: "Redes", action: onSocialClick },
    { label: "Ubicación", action: onLocationClick },
  ];

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-500",
        scrolled
          ? "bg-white/95 backdrop-blur-md shadow-sm border-b border-amber-100"
          : "bg-transparent"
      )}
    >
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2.5 group">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center shadow-sm">
            <Scissors className="w-4 h-4 text-white" strokeWidth={1.5} />
          </div>
          <div className="flex flex-col leading-none">
            <span
              className={cn(
                "font-serif-display font-bold text-lg tracking-wide transition-colors duration-300",
                scrolled ? "text-stone-900" : "text-white drop-shadow"
              )}
            >
              FRANCO
            </span>
            <span
              className={cn(
                "font-cormorant text-xs tracking-[0.2em] uppercase transition-colors duration-300",
                scrolled ? "text-amber-600" : "text-amber-300"
              )}
            >
              Trends & Beauty
            </span>
          </div>
        </Link>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map(link => (
            <button
              key={link.label}
              onClick={link.action}
              className={cn(
                "font-cormorant text-sm tracking-[0.12em] uppercase transition-all duration-300 hover:text-amber-500 relative group",
                scrolled ? "text-stone-700" : "text-white/90"
              )}
            >
              {link.label}
              <span className="absolute -bottom-0.5 left-0 w-0 h-px bg-amber-500 transition-all duration-300 group-hover:w-full" />
            </button>
          ))}
          <Link href="/reservar">
            <Button
              size="sm"
              className="bg-amber-500 hover:bg-amber-600 text-white font-cormorant tracking-[0.1em] uppercase text-sm px-6 rounded-none border-0 shadow-sm"
            >
              Reservar Turno
            </Button>
          </Link>
        </div>

        {/* Mobile toggle */}
        <button
          className={cn("md:hidden transition-colors", scrolled ? "text-stone-900" : "text-white")}
          onClick={() => setMobileOpen(v => !v)}
          aria-label="Menú"
        >
          {mobileOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white/98 backdrop-blur-md border-t border-amber-100 px-6 py-6 flex flex-col gap-5 shadow-lg">
          {navLinks.map(link => (
            <button
              key={link.label}
              onClick={() => { link.action(); setMobileOpen(false); }}
              className="font-cormorant text-base tracking-[0.12em] uppercase text-stone-700 hover:text-amber-600 text-left transition-colors"
            >
              {link.label}
            </button>
          ))}
          <Link href="/reservar" onClick={() => setMobileOpen(false)}>
            <Button className="w-full bg-amber-500 hover:bg-amber-600 text-white font-cormorant tracking-[0.1em] uppercase rounded-none">
              Reservar Turno
            </Button>
          </Link>
        </div>
      )}
    </nav>
  );
}
