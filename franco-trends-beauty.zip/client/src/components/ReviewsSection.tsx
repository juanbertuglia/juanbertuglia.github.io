import { trpc } from "@/lib/trpc";
import { Star, Quote } from "lucide-react";
import { cn } from "@/lib/utils";

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {[1, 2, 3, 4, 5].map(i => (
        <Star
          key={i}
          className={cn("w-4 h-4", i <= rating ? "fill-amber-400 text-amber-400" : "fill-stone-200 text-stone-200")}
        />
      ))}
    </div>
  );
}

export default function ReviewsSection() {
  const { data: reviews, isLoading } = trpc.reviews.list.useQuery();

  return (
    <section className="section-padding bg-stone-900 relative overflow-hidden">
      {/* Decorative */}
      <div className="absolute top-0 left-0 w-64 h-64 bg-amber-500/5 rounded-full -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-amber-500/5 rounded-full translate-x-1/3 translate-y-1/3" />

      <div className="relative container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="font-cormorant text-amber-400 tracking-[0.35em] uppercase text-sm mb-3">
            Testimonios
          </p>
          <h2 className="font-serif-display text-4xl md:text-5xl text-white mb-5">
            Lo que dicen nuestras clientas
          </h2>
          <div className="gold-divider mb-5" />
          <p className="font-cormorant text-stone-400 text-lg max-w-xl mx-auto">
            La satisfacción de cada clienta es nuestra mayor recompensa y el reflejo de nuestro compromiso con la excelencia.
          </p>
        </div>

        {/* Reviews grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-48 bg-stone-800 animate-pulse rounded-sm" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews?.map((review, i) => (
              <div
                key={review.id}
                className="bg-stone-800/60 border border-stone-700/50 p-7 hover:border-amber-500/30 transition-all duration-300 animate-fade-in-up group"
                style={{ animationDelay: `${i * 0.1}s`, opacity: 0 }}
              >
                {/* Quote icon */}
                <Quote className="w-8 h-8 text-amber-500/30 mb-4 group-hover:text-amber-500/50 transition-colors" />

                {/* Comment */}
                <p className="font-cormorant text-stone-300 text-base leading-relaxed mb-6 italic">
                  "{review.comment}"
                </p>

                {/* Footer */}
                <div className="flex items-center justify-between pt-4 border-t border-stone-700/50">
                  <div>
                    <p className="font-serif-display text-white text-sm font-medium">
                      {review.clientName}
                    </p>
                    {review.service && (
                      <p className="font-cormorant text-amber-400/70 text-xs tracking-wide mt-0.5">
                        {review.service}
                      </p>
                    )}
                  </div>
                  <StarRating rating={review.rating} />
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Average rating */}
        {reviews && reviews.length > 0 && (
          <div className="text-center mt-14">
            <div className="inline-flex flex-col items-center gap-3 bg-stone-800/40 border border-stone-700/40 px-10 py-6">
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(i => (
                  <Star key={i} className="w-5 h-5 fill-amber-400 text-amber-400" />
                ))}
              </div>
              <p className="font-cormorant text-white text-lg">
                <span className="font-serif-display text-3xl text-amber-400 mr-2">
                  {(reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length).toFixed(1)}
                </span>
                de 5 — basado en {reviews.length} reseñas
              </p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
