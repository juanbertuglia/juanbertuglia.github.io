import { MapPin, Clock, Phone, Mail } from "lucide-react";

const BUSINESS_ADDRESS = "Aguirre 99, C1414 Ciudad Autónoma de Buenos Aires";
const MAPS_EMBED_URL = `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3283.8196409999997!2d-58.37944!3d-34.6065!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x95bccb5e5e5e5e5e%3A0x5e5e5e5e5e5e5e5e!2sAguirre%2099%2C%20C1414%20CABA!5e0!3m2!1ses!2sar!4v1700000000000!5m2!1ses!2sar`;

const schedule = [
  { day: "Martes a Viernes", hours: "9:00 — 20:00" },
  { day: "Sábados", hours: "9:00 — 20:00" },
  { day: "Lunes y Domingos", hours: "Cerrado" },
];

const contactInfo = [
  { icon: MapPin, label: "Dirección", value: BUSINESS_ADDRESS },
  { icon: Phone, label: "Teléfono", value: "+54 9 11 0000-0000" },
  { icon: Mail, label: "Email", value: "info@franco-beauty.com" },
];

export default function LocationSection() {
  return (
    <section className="section-padding bg-stone-50">
      <div className="container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="font-cormorant text-amber-600 tracking-[0.35em] uppercase text-sm mb-3">
            Dónde encontrarnos
          </p>
          <h2 className="font-serif-display text-4xl md:text-5xl text-stone-900 mb-5">
            Nuestra Ubicación
          </h2>
          <div className="gold-divider mb-5" />
          <p className="font-cormorant text-stone-500 text-lg max-w-xl mx-auto">
            Visitanos en nuestro salón y viví la experiencia FRANCO Trends & Beauty en persona.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-0 shadow-lg overflow-hidden max-w-6xl mx-auto">
          {/* Map */}
          <div className="lg:col-span-3 h-80 lg:h-auto min-h-[400px]">
            <iframe
              src={MAPS_EMBED_URL}
              width="100%"
              height="100%"
              style={{ border: 0, minHeight: "400px" }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Ubicación FRANCO Trends & Beauty"
            />
          </div>

          {/* Info panel */}
          <div className="lg:col-span-2 bg-stone-900 text-white p-10 flex flex-col justify-between">
            <div>
              <h3 className="font-serif-display text-2xl text-white mb-1">FRANCO</h3>
              <p className="font-cormorant text-amber-400 tracking-[0.2em] uppercase text-sm mb-8">
                Trends & Beauty
              </p>

              {/* Contact info */}
              <div className="space-y-5 mb-10">
                {contactInfo.map(({ icon: Icon, label, value }) => (
                  <div key={label} className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-full bg-amber-500/10 border border-amber-500/20 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Icon className="w-3.5 h-3.5 text-amber-400" />
                    </div>
                    <div>
                      <p className="font-cormorant text-stone-400 text-xs tracking-[0.15em] uppercase mb-0.5">
                        {label}
                      </p>
                      <p className="font-cormorant text-white text-sm leading-snug">
                        {value}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              {/* Schedule */}
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Clock className="w-4 h-4 text-amber-400" />
                  <p className="font-cormorant text-amber-400 tracking-[0.15em] uppercase text-xs">
                    Horarios de atención
                  </p>
                </div>
                <div className="space-y-2">
                  {schedule.map(({ day, hours }) => (
                    <div key={day} className="flex justify-between items-center py-2 border-b border-stone-800">
                      <span className="font-cormorant text-stone-300 text-sm">{day}</span>
                      <span className={`font-cormorant text-sm ${hours === 'Cerrado' ? 'text-stone-500' : 'text-amber-400'}`}>
                        {hours}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* CTA */}
            <a
              href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(BUSINESS_ADDRESS)}`}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 flex items-center justify-center gap-2 bg-amber-500 hover:bg-amber-600 text-white font-cormorant tracking-[0.15em] uppercase text-sm py-3.5 transition-colors duration-300"
            >
              <MapPin className="w-4 h-4" />
              Cómo llegar
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
