import { Link } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Scissors, Palette, Sparkles, Crown, Heart, Star } from "lucide-react";
import { cn } from "@/lib/utils";

const SERVICES_BG = "https://d2xsxph8kpxj0f.cloudfront.net/310519663788046739/n68B7ePV8N8GNoJYdRJ5V7/franco-services-bg-joaDbyWqnAfizfqwqNNCuX.webp";

const categoryIcons: Record<string, React.ReactNode> = {
  Cabello: <Scissors className="w-5 h-5" />,
  Color: <Palette className="w-5 h-5" />,
  Tratamientos: <Sparkles className="w-5 h-5" />,
  Peinados: <Crown className="w-5 h-5" />,
  Uñas: <Heart className="w-5 h-5" />,
  Maquillaje: <Star className="w-5 h-5" />,
};

export default function ServicesSection() {
  const { data: services, isLoading } = trpc.services.list.useQuery();

  const formatPrice = (price: number) =>
    new Intl.NumberFormat("es-AR", { style: "currency", currency: "ARS", maximumFractionDigits: 0 }).format(price);

  return (
    <section id="services" className="relative section-padding overflow-hidden">
      {/* Subtle background */}
      <div className="absolute inset-0 bg-stone-50" />
      <div
        className="absolute inset-0 opacity-[0.03] bg-cover bg-center"
        style={{ backgroundImage: `url(${SERVICES_BG})` }}
      />

      <div className="relative container mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16">
          <p className="font-cormorant text-amber-600 tracking-[0.35em] uppercase text-sm mb-3">
            Lo que ofrecemos
          </p>
          <h2 className="font-serif-display text-4xl md:text-5xl text-stone-900 mb-5">
            Nuestros Servicios
          </h2>
          <div className="gold-divider mb-5" />
          <p className="font-cormorant text-stone-500 text-lg max-w-xl mx-auto">
            Cada servicio es una experiencia diseñada para realzar tu belleza natural con técnicas de vanguardia y productos de alta gama.
          </p>
        </div>

        {/* Services grid */}
        {isLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[...Array(8)].map((_, i) => (
              <div key={i} className="h-64 bg-stone-200 animate-pulse rounded-sm" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {services?.map((service, i) => (
              <div
                key={service.id}
                className={cn(
                  "group bg-white border border-stone-100 p-7 hover:border-amber-200 hover:shadow-lg transition-all duration-400 cursor-default",
                  "animate-fade-in-up"
                )}
                style={{ animationDelay: `${i * 0.07}s`, opacity: 0 }}
              >
                {/* Icon */}
                <div className="w-10 h-10 rounded-full bg-amber-50 border border-amber-100 flex items-center justify-center text-amber-600 mb-5 group-hover:bg-amber-500 group-hover:text-white group-hover:border-amber-500 transition-all duration-300">
                  {categoryIcons[service.category ?? ""] ?? <Scissors className="w-5 h-5" />}
                </div>

                {/* Category badge */}
                {service.category && (
                  <span className="font-cormorant text-xs tracking-[0.2em] uppercase text-amber-500 mb-2 block">
                    {service.category}
                  </span>
                )}

                {/* Name */}
                <h3 className="font-serif-display text-lg text-stone-900 mb-2 leading-snug">
                  {service.name}
                </h3>

                {/* Description */}
                <p className="font-cormorant text-stone-500 text-sm leading-relaxed mb-5 line-clamp-3">
                  {service.description}
                </p>

                {/* Footer */}
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-stone-100">
                  <span className="font-serif-display text-xl text-amber-600 font-semibold">
                    {formatPrice(service.price)}
                  </span>
                  <span className="font-cormorant text-xs text-stone-400 tracking-wide">
                    {service.durationMinutes} min
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* CTA */}
        <div className="text-center mt-14">
          <Link href="/reservar">
            <Button
              size="lg"
              className="bg-stone-900 hover:bg-amber-600 text-white font-cormorant tracking-[0.15em] uppercase text-base px-12 py-6 rounded-none transition-all duration-300 shadow-sm"
            >
              Reservar un Turno
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
}
