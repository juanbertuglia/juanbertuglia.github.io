import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";

const HERO_IMAGE = "https://d2xsxph8kpxj0f.cloudfront.net/310519663788046739/n68B7ePV8N8GNoJYdRJ5V7/franco-hero-mL57ULJgPwRY8QUpM7RSpP.webp";

export default function HeroSection() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background image */}
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${HERO_IMAGE})` }}
      />
      {/* Overlay gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-black/40 to-black/70" />

      {/* Content */}
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        {/* Eyebrow */}
        <p
          className="font-cormorant text-amber-300 tracking-[0.4em] uppercase text-sm mb-6 animate-fade-in-up"
          style={{ animationDelay: "0.1s", opacity: 0 }}
        >
          Salón de Belleza Premium
        </p>

        {/* Main title */}
        <h1
          className="font-serif-display text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-4 leading-none animate-fade-in-up"
          style={{ animationDelay: "0.25s", opacity: 0 }}
        >
          FRANCO
        </h1>
        <h2
          className="font-cormorant text-2xl md:text-3xl lg:text-4xl font-light text-amber-300 tracking-[0.3em] uppercase mb-8 animate-fade-in-up"
          style={{ animationDelay: "0.4s", opacity: 0 }}
        >
          Trends & Beauty
        </h2>

        {/* Divider */}
        <div
          className="flex items-center justify-center gap-4 mb-8 animate-fade-in-up"
          style={{ animationDelay: "0.55s", opacity: 0 }}
        >
          <div className="h-px w-16 bg-amber-400/60" />
          <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
          <div className="h-px w-16 bg-amber-400/60" />
        </div>

        {/* Tagline */}
        <p
          className="font-cormorant text-white/80 text-xl md:text-2xl italic mb-12 animate-fade-in-up"
          style={{ animationDelay: "0.65s", opacity: 0 }}
        >
          Donde cada detalle es una obra de arte
        </p>

        {/* CTAs */}
        <div
          className="flex flex-col sm:flex-row items-center justify-center gap-4 animate-fade-in-up"
          style={{ animationDelay: "0.8s", opacity: 0 }}
        >
          <Link href="/reservar">
            <Button
              size="lg"
              className="bg-amber-500 hover:bg-amber-600 text-white font-cormorant tracking-[0.15em] uppercase text-base px-10 py-6 rounded-none shadow-lg hover:shadow-amber-500/30 transition-all duration-300"
            >
              Reservar Turno
            </Button>
          </Link>
          <button
            onClick={() => document.getElementById('services')?.scrollIntoView({ behavior: 'smooth' })}
            className="font-cormorant text-white/80 hover:text-amber-300 tracking-[0.15em] uppercase text-base border border-white/30 hover:border-amber-400/60 px-10 py-3 transition-all duration-300"
          >
            Ver Servicios
          </button>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-6 h-6 text-white/50" />
      </div>
    </section>
  );
}
