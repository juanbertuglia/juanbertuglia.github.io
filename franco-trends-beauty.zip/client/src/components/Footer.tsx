import { Link } from "wouter";
import { Scissors } from "lucide-react";

interface FooterProps {
  onServicesClick: () => void;
  onLocationClick: () => void;
}

export default function Footer({ onServicesClick, onLocationClick }: FooterProps) {
  return (
    <footer className="bg-stone-950 text-white">
      <div className="container mx-auto px-6 py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {/* Brand */}
          <div>
            <div className="flex items-center gap-2.5 mb-5">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-amber-400 to-amber-600 flex items-center justify-center">
                <Scissors className="w-4 h-4 text-white" strokeWidth={1.5} />
              </div>
              <div>
                <div className="font-serif-display text-lg font-bold text-white leading-none">FRANCO</div>
                <div className="font-cormorant text-xs text-amber-400 tracking-[0.2em] uppercase">Trends & Beauty</div>
              </div>
            </div>
            <p className="font-cormorant text-stone-400 text-sm leading-relaxed max-w-xs">
              Salón de belleza premium donde cada visita es una experiencia transformadora. Arte, elegancia y profesionalismo en cada servicio.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="font-serif-display text-white text-base mb-5">Navegación</h4>
            <ul className="space-y-3">
              {[
                { label: "Inicio", href: "/" },
                { label: "Servicios", action: onServicesClick },
                { label: "Reservar Turno", href: "/reservar" },
                { label: "Ubicación", action: onLocationClick },
              ].map(item => (
                <li key={item.label}>
                  {item.href ? (
                    <Link href={item.href} className="font-cormorant text-stone-400 hover:text-amber-400 text-sm tracking-wide transition-colors">
                      {item.label}
                    </Link>
                  ) : (
                    <button
                      onClick={item.action}
                      className="font-cormorant text-stone-400 hover:text-amber-400 text-sm tracking-wide transition-colors"
                    >
                      {item.label}
                    </button>
                  )}
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="font-serif-display text-white text-base mb-5">Contacto</h4>
            <ul className="space-y-3">
              <li className="font-cormorant text-stone-400 text-sm">Aguirre 99, C1414 CABA</li>
              <li className="font-cormorant text-stone-400 text-sm">+54 9 11 0000-0000</li>
              <li className="font-cormorant text-stone-400 text-sm">info@franco-beauty.com</li>
              <li className="font-cormorant text-stone-400 text-sm mt-4">
                Mar–Vie: 9:00 – 20:00<br />
                Sáb: 9:00 – 20:00
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-stone-800 mt-12 pt-8 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="font-cormorant text-stone-500 text-sm">
            © {new Date().getFullYear()} FRANCO Trends & Beauty. Todos los derechos reservados.
          </p>
          <div className="flex gap-6">
            {["Instagram", "Facebook", "TikTok"].map(net => (
              <a
                key={net}
                href={`https://${net.toLowerCase()}.com/franco.trendsbeauty`}
                target="_blank"
                rel="noopener noreferrer"
                className="font-cormorant text-stone-500 hover:text-amber-400 text-xs tracking-[0.15em] uppercase transition-colors"
              >
                {net}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
