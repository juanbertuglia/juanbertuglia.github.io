/**
 * Google Calendar Integration for FRANCO Trends & Beauty
 *
 * Uses Google Calendar API v3 with a Service Account or OAuth2 credentials.
 * Requires the following environment variables:
 *   - GOOGLE_CALENDAR_ID: The calendar ID to add events to
 *   - GOOGLE_SERVICE_ACCOUNT_EMAIL: Service account email
 *   - GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY: Service account private key (PEM)
 *
 * OR using OAuth2:
 *   - GOOGLE_CALENDAR_ID
 *   - GOOGLE_CLIENT_ID
 *   - GOOGLE_CLIENT_SECRET
 *   - GOOGLE_REFRESH_TOKEN
 */

interface CalendarEventResult {
  eventId: string;
  eventLink: string;
}

interface CreateEventParams {
  appointmentId: number;
  clientName: string;
  clientEmail: string;
  serviceName: string;
  date: string;   // YYYY-MM-DD
  time: string;   // HH:MM
  notes?: string;
}

function getGoogleConfig() {
  const calendarId = process.env.GOOGLE_CALENDAR_ID;
  const clientId = process.env.GOOGLE_CLIENT_ID;
  const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
  const refreshToken = process.env.GOOGLE_REFRESH_TOKEN;

  return { calendarId, clientId, clientSecret, refreshToken };
}

async function getAccessToken(): Promise<string | null> {
  const { clientId, clientSecret, refreshToken } = getGoogleConfig();

  if (!clientId || !clientSecret || !refreshToken) {
    return null;
  }

  try {
    const response = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id: clientId,
        client_secret: clientSecret,
        refresh_token: refreshToken,
        grant_type: 'refresh_token',
      }),
    });

    if (!response.ok) {
      const err = await response.text();
      console.warn('[Google Calendar] Token refresh failed:', err);
      return null;
    }

    const data = await response.json() as { access_token: string };
    return data.access_token;
  } catch (err) {
    console.warn('[Google Calendar] Error getting access token:', err);
    return null;
  }
}

export async function createGoogleCalendarEvent(
  params: CreateEventParams
): Promise<CalendarEventResult | null> {
  const { calendarId } = getGoogleConfig();

  if (!calendarId) {
    console.warn('[Google Calendar] GOOGLE_CALENDAR_ID not configured, skipping.');
    return null;
  }

  const accessToken = await getAccessToken();
  if (!accessToken) {
    console.warn('[Google Calendar] Could not obtain access token, skipping.');
    return null;
  }

  // Build start/end datetime (assume 1 hour duration)
  const [year, month, day] = params.date.split('-').map(Number);
  const [hour, minute] = params.time.split(':').map(Number);

  const startDate = new Date(year, month - 1, day, hour, minute);
  const endDate = new Date(startDate.getTime() + 60 * 60 * 1000); // +1 hour

  const toISOLocal = (d: Date) => {
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}:00`;
  };

  const event = {
    summary: `${params.serviceName} — ${params.clientName}`,
    description: [
      `Turno agendado en FRANCO Trends & Beauty`,
      `Cliente: ${params.clientName}`,
      `Email: ${params.clientEmail}`,
      `Servicio: ${params.serviceName}`,
      params.notes ? `Notas: ${params.notes}` : '',
      `ID Turno: #${params.appointmentId}`,
    ].filter(Boolean).join('\n'),
    start: {
      dateTime: toISOLocal(startDate),
      timeZone: 'America/Argentina/Buenos_Aires',
    },
    end: {
      dateTime: toISOLocal(endDate),
      timeZone: 'America/Argentina/Buenos_Aires',
    },
    attendees: [
      { email: params.clientEmail, displayName: params.clientName },
    ],
    reminders: {
      useDefault: false,
      overrides: [
        { method: 'email', minutes: 60 },
        { method: 'popup', minutes: 30 },
      ],
    },
    colorId: '11', // Tomato red for visibility
  };

  try {
    const encodedCalendarId = encodeURIComponent(calendarId);
    const response = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodedCalendarId}/events?sendUpdates=all`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${accessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(event),
      }
    );

    if (!response.ok) {
      const err = await response.text();
      console.warn('[Google Calendar] Failed to create event:', err);
      return null;
    }

    const data = await response.json() as { id: string; htmlLink: string };
    return {
      eventId: data.id,
      eventLink: data.htmlLink,
    };
  } catch (err) {
    console.warn('[Google Calendar] Error creating event:', err);
    return null;
  }
}

export async function deleteGoogleCalendarEvent(eventId: string): Promise<boolean> {
  const { calendarId } = getGoogleConfig();
  if (!calendarId) return false;

  const accessToken = await getAccessToken();
  if (!accessToken) return false;

  try {
    const encodedCalendarId = encodeURIComponent(calendarId);
    const response = await fetch(
      `https://www.googleapis.com/calendar/v3/calendars/${encodedCalendarId}/events/${eventId}`,
      {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${accessToken}` },
      }
    );
    return response.ok || response.status === 404;
  } catch {
    return false;
  }
}
