import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import {
  getActiveServices,
  getAllServices,
  createAppointment,
  getAllAppointments,
  getAppointmentById,
  updateAppointmentStatus,
  getApprovedReviews,
  getAllReviews,
  getAppointmentsByDate,
} from "./db";

// Admin guard middleware
const adminProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN', message: 'Acceso restringido al administrador.' });
  }
  return next({ ctx });
});

export const appRouter = router({
  system: systemRouter,

  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Services ────────────────────────────────────────────────────────────
  services: router({
    list: publicProcedure.query(async () => {
      const items = await getActiveServices();
      return items.map(s => ({
        ...s,
        price: Number(s.price),
      }));
    }),
    listAll: adminProcedure.query(async () => {
      const items = await getAllServices();
      return items.map(s => ({ ...s, price: Number(s.price) }));
    }),
  }),

  // ─── Appointments ─────────────────────────────────────────────────────────
  appointments: router({
    create: publicProcedure
      .input(z.object({
        clientName: z.string().min(2, "Nombre requerido"),
        clientEmail: z.string().email("Email inválido"),
        clientPhone: z.string().min(6, "Teléfono requerido"),
        serviceId: z.number().int().positive(),
        serviceName: z.string(),
        appointmentDate: z.string().regex(/^\d{4}-\d{2}-\d{2}$/, "Fecha inválida"),
        appointmentTime: z.string().regex(/^\d{2}:\d{2}$/, "Hora inválida"),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        // Insert appointment as confirmed
        await createAppointment({
          ...input,
          notes: input.notes ?? null,
          status: 'confirmed',
        });

        // Get the created appointment
        const all = await getAllAppointments();
        const created = all.find(a =>
          a.clientEmail === input.clientEmail &&
          a.appointmentDate === input.appointmentDate &&
          a.appointmentTime === input.appointmentTime
        );

        return { success: true, appointmentId: created?.id ?? null, calendarLink: null };
      }),

    getAvailableTimes: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        const booked = await getAppointmentsByDate(input.date);
        const bookedTimes = booked.map(a => a.appointmentTime);

        // Generate slots 9:00 to 19:30 every 30 min
        const slots: string[] = [];
        for (let h = 9; h < 20; h++) {
          for (const m of [0, 30]) {
            const time = `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
            slots.push(time);
          }
        }

        return slots.map(time => ({
          time,
          available: !bookedTimes.includes(time),
        }));
      }),
  }),

  // ─── Reviews ─────────────────────────────────────────────────────────────
  reviews: router({
    list: publicProcedure.query(async () => {
      return getApprovedReviews();
    }),
  }),

  // ─── Admin ───────────────────────────────────────────────────────────────
  admin: router({
    appointments: adminProcedure.query(async () => {
      return getAllAppointments();
    }),

    updateStatus: adminProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(['pending', 'confirmed', 'cancelled', 'completed']),
      }))
      .mutation(async ({ input }) => {
        await updateAppointmentStatus(input.id, input.status);
        return { success: true };
      }),

    reviews: adminProcedure.query(async () => {
      return getAllReviews();
    }),

    stats: adminProcedure.query(async () => {
      const all = await getAllAppointments();
      const total = all.length;
      const confirmed = all.filter(a => a.status === 'confirmed').length;
      const pending = all.filter(a => a.status === 'pending').length;
      const cancelled = all.filter(a => a.status === 'cancelled').length;
      const completed = all.filter(a => a.status === 'completed').length;

      // Today's appointments
      const today = new Date().toISOString().split('T')[0];
      const todayAppts = all.filter(a => a.appointmentDate === today);

      return { total, confirmed, pending, cancelled, completed, todayCount: todayAppts.length };
    }),
  }),
});

export type AppRouter = typeof appRouter;
